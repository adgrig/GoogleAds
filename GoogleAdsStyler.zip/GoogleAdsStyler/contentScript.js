   'use strict';
   document.onload = function (){
    document.getElementById("tads").style.backgroundColor = "#fff5d9";
}();