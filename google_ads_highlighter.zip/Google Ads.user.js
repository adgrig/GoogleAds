// ==UserScript==
// @name         Google Ads
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.google.com/search*
// @include      https://www.google.com/search*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    document.getElementById("tads").style.backgroundColor = "#fff5d9"
})();